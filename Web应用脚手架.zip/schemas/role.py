from datetime import datetime
from pydantic import Field, BaseModel, validator
from typing import Optional, List
from schemas.base import BaseResp, ResAntTable


class CreateRole(BaseModel):
    role_name: Optional[str]
    role_desc: Optional[str]
    accesses: List[int] = []


class UpdataRole(BaseModel):
    id: int
    role_name: Optional[str]
    role_desc: Optional[str]
    accesses: List[int] = []