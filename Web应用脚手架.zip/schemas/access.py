from datetime import datetime
from pydantic import Field, BaseModel, validator
from typing import Optional, List
from schemas.base import BaseResp, ResAntTable


class CreateAccess(BaseModel):
    access_name: Optional[str]
    access_desc: Optional[str]
    scopes: Optional[str]


class UpdataAccess(BaseModel):
    id: int
    access_name: Optional[str]
    access_desc: Optional[str]
    scopes: Optional[str]


class RoleAccess(BaseModel):
    id: int
    roles: List[int] = []


class CreateMenu(BaseModel):
    access_id: int
    id: Optional[int]
    path: Optional[str]
    name: Optional[str]
    url: Optional[str]
    icon: Optional[str]
    child_menus: Optional[list]


class AccessLogQuery(BaseModel):
    user_id: Optional[int]
    username: Optional[str]
    page: int
    limit: int