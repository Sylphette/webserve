# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : mysql.py
# @Des: mysql数据库配置
from fastapi import FastAPI
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import os


# -----------------------数据库配置-----------------------------------
class BASEDB:
    _SQLALCHEMY_DATABASE_URL = \
        f"mysql+mysqlconnector://{os.getenv('BASE_USER', 'root')}:{os.getenv('BASE_PASSWORD', '123456')}" \
        f"@{os.getenv('BASE_HOST', '127.0.0.1')}:{int(os.getenv('BASE_PORT', 3306))}/{os.getenv('BASE_DB', 'base')}" \
        f"?auth_plugin=mysql_native_password"

    engine = create_engine(
        _SQLALCHEMY_DATABASE_URL,
        echo=False
    )
    # 创建会话对象
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    # 定义一个ORM模型基类
    Base = declarative_base(bind=engine, name="Base")

    # 创建表方法
    @staticmethod
    def init_db():
        BASEDB.Base.metadata.create_all(bind=BASEDB.engine)  # 将所有继承自Base的子类创建表单

    # 删除表方法
    @staticmethod
    def drop_db():
        BASEDB.Base.metadata.drop_all(bind=BASEDB.engine)


# 将Base赋值给BASE变量
BaseDb = BASEDB.Base


class WithBaseDb:
    def __init__(self):
        self.db = BASEDB.SessionLocal()

    def __enter__(self): # 上下文管理器，进入with调用
        return self.db

    def __exit__(self, exc_type, exc_val, exc_tb): # 上下文管理器，退出with调用
        self.db.close()


def get_db():
    """
    初始化会话对象，并yield返回并关闭会话
    :return:
    """
    db = BASEDB.SessionLocal()
    try:
        yield db
    finally:
        db.close()


# -----------------------服务数据库配置-----------------------------------
class SERVEDB:
    _SQLALCHEMY_DATABASE_URL = \
        f"mysql+mysqlconnector://{os.getenv('BASE_USER', 'root')}:{os.getenv('BASE_PASSWORD', '123456')}" \
        f"@{os.getenv('BASE_HOST', '127.0.0.1')}:{int(os.getenv('BASE_PORT', 3306))}/{os.getenv('SERVE_DB', 'serve')}" \
        f"?auth_plugin=mysql_native_password"

    engine = create_engine(
        _SQLALCHEMY_DATABASE_URL,
        echo=False
    )
    # 创建会话对象
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    # 定义一个ORM模型基类
    Base = declarative_base(bind=engine, name="Base")

    # 创建表方法
    @staticmethod
    def init_db():
        SERVEDB.Base.metadata.create_all(bind=SERVEDB.engine)  # 将所有继承自Base的子类创建表单

    # 删除表方法
    @staticmethod
    def drop_db():
        SERVEDB.Base.metadata.drop_all(bind=SERVEDB.engine)


# 将Base赋值给BASE变量
ServeDb = SERVEDB.Base


class WithServeDb:
    def __init__(self):
        self.db = SERVEDB.SessionLocal()

    def __enter__(self): # 上下文管理器，进入with调用
        return self.db

    def __exit__(self, exc_type, exc_val, exc_tb): # 上下文管理器，退出with调用
        self.db.close()


def get_serve_db():
    """
    初始化会话对象，并yield返回并关闭会话
    :return:
    """
    db = SERVEDB.SessionLocal()
    try:
        yield db
    finally:
        db.close()
