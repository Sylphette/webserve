from sqlalchemy import Column, Integer, String, DateTime, Text, Float, Boolean, JSON, ForeignKey, Table
from database.mysql import SERVEDB, ServeDb
from datetime import datetime
from sqlalchemy.orm import relationship, backref


class Services(ServeDb):
    """服务器映射表"""
    __tablename__ = 'services'
    __default__ = {}
    id = Column(Integer, primary_key=True, autoincrement=True)
    ip = Column(String(255), nullable=False, index=True)
    model = Column(String(255), nullable=False, index=True)
    status = Column(String(255), nullable=False, default="未知")  # 通信异常 未知 通讯正常 服务异常
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")