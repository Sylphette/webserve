# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : base.py
# @Des: 用户数据库
from sqlalchemy import Column, Integer, String, DateTime, Text, Float, Boolean, JSON, ForeignKey, Table
from database.mysql import BASEDB, BaseDb
from datetime import datetime
from sqlalchemy.orm import relationship, backref


# 多对多的中间关系
role_access = Table(
    "role_access", # 表名
    BaseDb.metadata,  # 表继承的类
    Column("id", Integer, primary_key=True),
    Column("role_id", Integer, ForeignKey("role.id", ondelete="CASCADE")), # 添加级联删除，CASCADE表示父表被删除之后子表也删除
    Column("access_id", Integer, ForeignKey("access.id", ondelete="CASCADE"))
)


class Role(BaseDb):
    __tablename__ = "role"
    id = Column(Integer, primary_key=True, autoincrement=True)
    role_name = Column(String(15), comment="角色名称")
    role_desc = Column(String(255), nullable=True, comment="角色描述")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")
    # 外键
    accesses = relationship("Access", backref="roles", secondary=role_access)


class Access(BaseDb):
    __tablename__ = "access"
    id = Column(Integer, primary_key=True, autoincrement=True)
    access_name = Column(String(15), comment="权限名称")
    scopes = Column(String(255), unique=True, comment="权限范围标识")
    access_desc = Column(String(255), nullable=True, comment="权限描述")
    is_menu = Column(Boolean, default=True, comment="是否渲染为菜单")
    menu_name = Column(String(255), nullable=True, comment="菜单名字")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")


class Menu(BaseDb):
    __tablename__ = "menu"
    id = Column(Integer, primary_key=True, autoincrement=True)
    access_id = Column(Integer, ForeignKey("access.id", ondelete='CASCADE'), comment="所属角色")
    path = Column(String(255), nullable=False, comment="路径")
    name = Column(String(255), nullable=False, comment="菜单名")
    url = Column(String(255), nullable=False, comment="文件路径")
    icon = Column(String(255), nullable=True, comment="菜单图标")
    # 外键
    access = relationship("Access", backref="menus") # 添加uselist=False表示一对一的关系
    # child_menu = relationship("ChildMenu", back_populates="menu")


class ChildMenu(BaseDb):
    __tablename__ = "child_menu"
    id = Column(Integer, primary_key=True, autoincrement=True)
    menu_id = Column(Integer, ForeignKey("menu.id", ondelete='CASCADE'), comment="所属父表")
    path = Column(String(255), nullable=False, comment="路径")
    name = Column(String(255), nullable=False, comment="菜单名")
    url = Column(String(255), nullable=False, comment="文件路径")
    # 外键
    menu = relationship("Menu", backref="child_menus")


class User(BaseDb):
    __tablename__ = "user"
    id = Column(Integer, primary_key=True, autoincrement=True)
    role_id = Column(Integer, ForeignKey("role.id", ondelete='SET NULL'), comment="所属角色") # 添加级联删除，SET NULL表示父表被删除之后子表设置为null
    identify_id = Column(String(20), unique=True, comment="用户的识别码")
    username = Column(String(20), nullable=True, comment="用户名", unique=True)
    user_type = Column(Boolean, default=False, comment="用户类型 True:超级管理员 False:普通管理员")
    password = Column(String(255), nullable=True)
    nickname = Column(String(255), default="用户", comment="昵称")
    user_phone = Column(String(11), nullable=True, comment="手机号")
    user_email = Column(String(255), nullable=True, comment="邮箱")
    full_name = Column(String(255), nullable=True, comment="姓名")
    user_status = Column(Integer, default=1, comment="1正常 0禁用")
    header_img = Column(String(255), nullable=True, comment="头像")
    sex = Column(Integer, default=0, comment="0男 1女")
    remarks = Column(String(30), nullable=True, comment="备注")
    client_host = Column(String(19), nullable=True, comment="访问ip")
    address = Column(String(20), nullable=True, comment="访问地址")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")
    # 外键
    role = relationship("Role", backref="users")


class OpenId(BaseDb):
    __tablename__ = "openid"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("user.id", ondelete='CASCADE'), comment="所属用户")
    openid = Column(String(255), nullable=False, unique=True, comment="微信openid")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")
    # 外键
    user = relationship("User", backref="openid", uselist=False)


class AccessLog(BaseDb):
    __tablename__ = "access_log"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("user.id", ondelete='CASCADE'), comment="所属用户")
    target_url = Column(String(255), nullable=True, comment="访问的url")
    user_agent = Column(String(255), nullable=True, comment="访问的UA")
    request_params = Column(JSON, nullable=True, comment="请求参数get|post")
    ip = Column(String(32), nullable=True, comment="访问IP")
    note = Column(String(255), nullable=True, comment="备注")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")
    # 外键
    user = relationship("User", backref=backref("accessLogs", order_by=create_time.desc()))


class SystemParams(BaseDb):
    __tablename__ = "system_params"
    id = Column(Integer, primary_key=True, autoincrement=True)
    params_name = Column(String(255), unique=True, comment="参数名")
    params = Column(JSON, comment="参数")
    # 时间
    create_time = Column(DateTime, default=datetime.now, comment="创建时间")
    update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")


BASEDB.init_db()
