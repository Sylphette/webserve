# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : views.py
# @Des: 视图总路由

from fastapi import APIRouter
from views.viewpoints import home

views_router = APIRouter()

views_router.include_router(home.router)