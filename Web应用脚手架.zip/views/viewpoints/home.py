# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : home.py
# @Des: 门户首页

from fastapi import Request, APIRouter, Cookie
from fastapi.responses import HTMLResponse
from typing import Optional

router = APIRouter()


@router.get("/", tags=["门户首页"], response_class=HTMLResponse)
async def home(request: Request):
    """
    门户首页
    :param request:
    :return:
    """
    return request.app.state.views.TemplateResponse("index.html", {"request": request})


@router.get("/home")
async def To_home(request: Request, session_id: Optional[str] = Cookie(None)):
    cookie = session_id
    session = request.session.get("session")
    page_data = {
        "cookie": cookie,
        "session": session
    }
    return request.app.state.views.TemplateResponse("index.html", {"request": request, **page_data})
