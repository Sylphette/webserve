# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : Config.py
# @Des: 基本配置文件

import os
from pydantic import BaseSettings
from typing import List
from dotenv import load_dotenv, find_dotenv


class Config(BaseSettings):
    # 加载环境变量
    load_dotenv(find_dotenv(), override=True)
    APP_DEBUG: bool = True
    # 项目信息
    VERSION: str = "0.0.1"
    PROJECT_NAME: str = "AI绘图"
    DESCRIPTION: str = '<a href="/redoc" target="_blank">redoc</a>'
    # 静态目录资源
    STATIC_DIR: str = os.path.join(os.getcwd(), "static")
    TEMPLATE_DIR: str = os.path.join(STATIC_DIR, "templates")
    # 跨域请求
    CORS_ORIGINS: List = ["*"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: List = ["*"]
    CORS_ALLOW_HEADERS: List = ["*"]
    # app端口
    HOST: str = "127.0.0.1"
    PORT: int = 8200
    # Session
    SECRET_KEY = "session" # 客户端cookie的键
    SESSION_COOKIE = "session_id" # 客户端的cookie的值
    SESSION_MAX_AGE = 14 * 24 * 60 * 60 # cookie的过期时间
    # Jwt
    JWT_SECRET_KEY = "1475a09331bc1954bb27ccd6d07a2326"
    JWT_ALGORITHM = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES = 14 * 24 * 60 * 60
    # wechat
    APP_ID = "wx819948fd3768b6bd"
    APP_SECRET = "0a388456b20d3ebd36d1a480fe8f3f60"


settings = Config()