# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : Events.py
# @Des: 事件监听

from typing import Callable
from fastapi import FastAPI
from database.redis import sys_cache


def startup(app: FastAPI) -> Callable: # callable能被调用的东西，如函数，类，类的方法等
    """
    FastApi启动事件
    :param app: FastAPI
    :return: start_app
    """
    async def app_start() -> None:
        print("服务已启动")
        app.state.cache = await sys_cache()

    return app_start


def stopping(app: FastAPI) -> Callable:
    """
    FastApi 停止事件
    :param app: FastAPI
    :return: stop_app
    """
    async def stop_app() -> None:
        # APP停止时触发
        print("服务已停止")

    return stop_app

