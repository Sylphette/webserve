# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : Helper.py
# @Des: 助手函数
import requests
from config import settings


def GetRelationShip(user):
    """
    获取用户的关联表信息
    :param user: 用户数据库的query数据
    :return:
    """
    if user.role:
        if len(user.role.accesses):
            for i in user.role.accesses:
                if len(i.menus):
                    for m in i.menus:
                        if m.child_menus:
                            pass


def GetWeChatOpenId(code: str):
    """
    获取openid
    :return:
    """
    wx_code_url = f"https://api.weixin.qq.com/sns/jscode2session?appid={settings.APP_ID}" \
                  f"&secret={ settings.APP_SECRET }&js_code={code}&grant_type=authorization_code"
    open_id = requests.get(wx_code_url)
    return open_id.json()


