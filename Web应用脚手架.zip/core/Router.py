# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : Router.py
# @Des: 路由聚合
from api.api import api_router as api_router
from views.views import views_router as view_router
from fastapi import APIRouter

router = APIRouter()
# 路由视图
router.include_router(view_router)
# API路由
router.include_router(api_router)


