
# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : Utils.py
# @Des: 工具函数
import hashlib
import random
import uuid
from passlib.handlers.pbkdf2 import pbkdf2_sha256
import time


def random_str():
    """
    唯一随机字符串
    :return: str
    """
    only = hashlib.md5(str(uuid.uuid1()).encode(encoding='UTF-8')).hexdigest()
    return str(only)


def check_password(password: str, old: str):
    """
    密码校验
    :param password: 用户输入的密码
    :param old: 数据库密码
    :return: Boolean
    """
    check = pbkdf2_sha256.verify(password, old)
    if check:
        return True
    else:
        return False


def code_number(ln: int):
    """
    随机数字
    :param ln: 长度
    :return: str
    """
    code = ""
    for i in range(ln):
        ch = chr(random.randrange(ord('0'), ord('9') + 1))
        code += ch

    return code


def en_password(psw: str):
    """
    密码加密
    :param psw: 需要加密的密码
    :return: 加密后的密码
    """
    password = pbkdf2_sha256.hash(psw)
    return password


def code_identity(id):
    """
    赋予用户uid
    :param id: 用户的内部id
    :return:
    """
    code = ""
    hash_code = ""
    id = 100000 + id
    for i in range(3):
        ch = chr(random.randrange(ord('0'), ord('9') + 1))
        hash_code += ch
    id = str(id)
    neglect_len = len(id) - 3
    for index, i in enumerate(id):
        if index + 1 - neglect_len > 0:
            code += i
            code += hash_code[index-neglect_len]
        else:
            code += i
    return code

