# -*- coding:utf-8 -*-
"""
@Time : 2023/4/4
@Author: Sylphiette
@Des: 登录接口
"""
from fastapi import Request, APIRouter, Cookie
from fastapi.responses import HTMLResponse
import json
import time
from wechatpy.oauth import WeChatOAuth
from wechatpy.exceptions import WeChatOAuthException
from fastapi import Request, APIRouter, Security, Depends
from core.Auth import create_access_token, check_permissions
from core.Response import fail, success
from models.base import SystemParams
from aioredis import Redis
from config import settings
from schemas.base import WechatOAuthData, WechatUserInfo
from models.base import User, OpenId
from database.mysql import get_db
from sqlalchemy.orm import Session
from core.Helper import GetWeChatOpenId
from api.account.common import write_access_log
from core.Helper import GetRelationShip
from core.Utils import en_password, random_str, code_identity

vistor_role_id = 2

router = APIRouter(prefix="/login")


@router.post("/wx")
async def post_login_byWeChat(req: Request, code: str, db: Session = Depends(get_db)):
    wx_result = GetWeChatOpenId(code)
    open_id = wx_result.get("openid")
    if open_id:
        openid = db.query(OpenId).filter(OpenId.openid == open_id).first()
        if openid: # 用户存在则走登录逻辑
            # 创建token
            jwt_data = {
                "user_id": openid.user.id,
                "user_type": openid.user.user_type
            }
            jwt_token = create_access_token(data=jwt_data)
            await write_access_log(req, openid.user.id, "通过微信登陆了系统!")
            GetRelationShip(openid.user)
            data = {
                "user": openid.user,
                "expires_in": settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                "token": jwt_token,
            }
            return success(msg="登录成功", data=data)
        else: # 用户不存在则走注册逻辑
            # 创建新用户
            new_user = User()
            user_name = "微信注册用户"
            new_user.username = user_name
            new_user.password = en_password("123456")
            new_user.role_id = vistor_role_id
            db.add(new_user)
            db.commit()
            # 修改用户账号等
            get_user = db.query(User).filter(User.username == user_name).first()
            username_code = code_identity(get_user.id)
            get_user.username = username_code
            get_user.identify_id = username_code
            get_user.nickname = "微信用户" + get_user.id
            # 创建该用户的open_id
            new_openid = OpenId()
            new_openid.openid = open_id
            new_openid.user_id = get_user.id
            db.add(new_openid)
            db.commit()
            # 创建token
            jwt_data = {
                "user_id": get_user.id,
                "user_type": get_user.user_type
            }
            jwt_token = create_access_token(data=jwt_data)
            await write_access_log(req, get_user.id, "通过微信登陆了系统!")
            GetRelationShip(get_user)
            data = {
                "user": get_user,
                "expires_in": settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                "token": jwt_token,
            }
            return success(msg="注册并登录成功", data=data)
    else: # 未获取到openid则返回前端获取授权失败
        return fail(msg="获取微信授权失败")