"""
@Time : 2023/4/4
@Author: Sylphiette
@Des: 管理员专用接口
"""
from fastapi import Request, APIRouter, Cookie, Form, Depends, Security
from fastapi.responses import HTMLResponse
from schemas.user import UserLogin, CreateUser, AccountLogin, UpdateUser, CreateVistor, UpdateVistor
from schemas.role import CreateRole, UpdataRole
from schemas.access import CreateAccess, UpdataAccess, RoleAccess, CreateMenu, AccessLogQuery
from database.mysql import get_db
from sqlalchemy.orm import Session
from models.base import User, Role, AccessLog, Menu, Access, ChildMenu
from core.Response import success, fail
from core.Utils import check_password, en_password, code_number, code_identity
from core.Auth import create_access_token
from config import settings
from api.account.common import write_access_log, write_access_log_sync
from core.Auth import check_permissions
from sqlalchemy import desc
from core.Helper import GetRelationShip

router = APIRouter(prefix="/admin")

vistor_role_id = 2


@router.post("/login", summary="管理员登录")
async def adminLogin(request: Request, post: AccountLogin, db: Session = Depends(get_db)):
    # 后台管理账号登录
    if post.username and post.password:
        get_user = db.query(User).filter(User.username == post.username).first()
        if get_user:
            if not get_user.password:
                return fail(msg=f"用户{get_user.username}密码验证失败!")
            if not check_password(post.password, get_user.password):  # 对密码进行加密校验
                return fail(msg=f"用户{get_user.username}密码验证失败!")
            if get_user.user_status == 0 or get_user.user_status == 2:
                return fail(msg=f"用户{get_user.username}未启用或已被管理员禁用!")
            # 创建token
            jwt_data = {
                "user_id": get_user.id,
                "user_type": get_user.user_type
            }
            jwt_token = create_access_token(data=jwt_data)
            await write_access_log(request, get_user.id, "通过用户名登陆了系统!")
            # 判空,并且调用了属性之后返回的数据就能带上关联表的数据
            logs = db.query(AccessLog).filter(AccessLog.user_id == get_user.id).order_by(desc("create_time")).limit(10).all()
            GetRelationShip(get_user)
            data = {
                "user": get_user,
                "expires_in": settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                "token": jwt_token,
                "log": logs
            }
            return success(msg="登录成功", data=data)
    return fail(msg="至少使用一种登录方式")


@router.get("/userlist",
            tags=["用户管理"],
            summary="获取用户信息",
            dependencies=[Security(check_permissions, scopes=["user_add"])])
async def getUserList(req: Request, db: Session = Depends(get_db)):
    datas = []
    # 查询参数中若有name，则进行用户模糊查询
    name = req.query_params.get("name")
    if name:
        users = db.query(User).filter(User.username.like(f'{name}%')).all()  # like模糊查询
        total = len(users)
        # 返回数据包括用户信息和角色信息
        for user in users:
            GetRelationShip(user)
            datas.append(user)
        data = {
            "total": total,
            "data": datas
        }
        return success(msg="获取成功", data=data)
    # 若没有name查询参数
    users = db.query(User).all()
    # 获取总数让前端好进行分页
    total = len(users)
    # 若有page和limit则进行分页查询
    page = req.query_params.get("page")
    limit = req.query_params.get("limit")
    if page and limit:
        page = int(page)
        limit = int(limit)
        users = db.query(User).order_by(User.id.asc()).offset((page - 1) * limit).limit(limit).all()  # desc()倒序，asc()正序
    for user in users:
        GetRelationShip(user)
        datas.append(user)
    data = {
        "total": total,
        "data": datas
    }
    return success(msg="获取成功", data=data)


@router.put("/userupdata",
            tags=["用户管理"],
            summary="修改用户资料",
            dependencies=[Security(check_permissions, scopes=["user_add"])])
async def putUserData(req: Request, post: UpdateUser, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == post.id).first()
    # db.commit()
    # db.close()
    # return success(msg="修改成功", data=user.first())
    # 若用id查询到对应用户，则进行数据判断和修改
    print(post)
    if user:
        if post.nickname is not None:
            user.nickname = post.nickname
        if post.user_type is not None:
            user.user_type = post.user_type
        if post.user_phone is not None:
            user.user_phone = post.user_phone
        if post.user_status is not None:
            user.user_status = post.user_status
        if post.sex is not None:
            user.sex = post.sex
        if post.role_id is not None:
            user.role_id = post.role_id
        if post.username is not None:
            user.username = post.username
        try:
            db.commit()
            db.close()
            return success(msg="修改成功", data=user)
        except Exception as e:
            print(e)
            if "Duplicate entry" in str(e):
                return fail(msg="用户名重复")

    else:
        return fail(msg="未查询到该用户")


@router.delete("/userdelete/{id}",
               tags=["用户管理"],
               summary="删除用户",
               dependencies=[Security(check_permissions, scopes=["user_add"])])
async def deleteUserData(req: Request, id: int, db: Session = Depends(get_db)):
    query = db.query(User).filter(User.id == id)
    if query.first():
        query.delete()
        db.commit()
        db.close()
        return success(msg="删除成功")
    return fail(msg="删除失败")


@router.get("/userreset/{id}",
            tags=["用户管理"],
            summary="重置密码",
            dependencies=[Security(check_permissions, scopes=["user_add"])])
async def resetPassword(req: Request, id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == id).first()
    if user:
        user.password = en_password("123456")
        db.commit()
        db.close()
        return success(msg="重置成功")
    return fail(msg="重置失败")


@router.post("/add",
             tags=["用户管理"],
             summary="管理员创建用户",
             dependencies=[Security(check_permissions, scopes=["user_add"])])
async def account_add(req: Request, post: CreateUser, db: Session = Depends(get_db)):
    if not post.password:
        post.password = '123456'
    newUser = User(**post.dict())
    newUser.password = en_password(newUser.password)
    if post.role_id:
        newUser.role_id = post.role_id
    try:
        db.add(newUser)
        db.commit()
        user = db.query(User).filter(User.username == post.username).first()
        user.identify_id = code_identity(user.id)
        db.commit()
        db.close()
    except Exception as e:
        if "Duplicate entry" in str(e):
            return fail(msg="用户名重复")
    return success(msg="添加成功")


@router.get("/rolelist",
            tags=["角色管理"],
            summary="获取角色信息",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def getRoleList(req: Request, db: Session = Depends(get_db)):
    roles = db.query(Role).all()
    # 调用角色的关联权限
    for role in roles:
        if role.accesses:
            pass
    return success(msg="获取成功", data=roles)


@router.post("/roleadd",
            tags=["角色管理"],
            summary="获取角色信息",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def postRoleAdd(req: Request, post: CreateRole, db: Session = Depends(get_db)):
    newRole = Role(role_name=post.role_name, role_desc=post.role_desc)
    if len(post.accesses) > 0:
        for id in post.accesses:
            access = db.query(Access).filter(Access.id == id).first()
            newRole.accesses.append(access)
    try:
        db.add(newRole)
        db.commit()
        db.close()
    except Exception as e:
        print(e)
        return fail(msg="添加失败")
    return success(msg="添加成功")


@router.put("/roleupdata",
            tags=["角色管理"],
            summary="修改角色资料",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def putRoleData(req: Request, post: UpdataRole, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.id == post.id).first()
    if role:
        if post.role_name is not None:
            role.role_name = post.role_name
        if post.role_desc is not None:
            role.role_desc = post.role_desc
        role.accesses = []
        if len(post.accesses) > 0:
            for id in post.accesses:
                access = db.query(Access).filter(Access.id == id).first()
                role.accesses.append(access)
        try:
            db.commit()
            db.close()
        except Exception as e:
            print(e)
            return fail(msg="修改失败")
        return success(msg="修改成功")
    return fail(msg="未查询到该角色")


@router.delete("/roledelete/{id}",
               tags=["角色管理"],
               summary="删除角色",
               dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def deleteUserData(req: Request, id: int, db: Session = Depends(get_db)):
    query = db.query(Role).filter(Role.id == id)
    if query.first():
        query.delete()
        db.commit()
        db.close()
        return success(msg="删除成功")
    return fail(msg="删除失败")


@router.get("/accesslist",
            tags=["通行证管理"],
            summary="获取通行证信息",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def getAccessList(req: Request, db: Session = Depends(get_db)):
    accesses = db.query(Access).all()
    # 调用角色的关联权限
    for access in accesses:
        if access.roles:
            pass
        if access.menus:
            for m in access.menus:
                if m.child_menus:
                    pass
    return success(msg="获取成功", data=accesses)


@router.post("/addaccess",
            tags=["通行证管理"],
            summary="添加通行证",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def postAddAccess(req: Request, post: CreateAccess, db: Session = Depends(get_db)):
    newAccess = Access(**post.dict())
    try:
        db.add(newAccess)
        db.commit()
        db.close()
    except Exception as e:
        print(e)
        return fail(msg="添加失败")
    return success(msg="添加成功")


@router.put("/accessupdata",
            tags=["通行证管理"],
            summary="修改通行证",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def putUpdataAccess(req: Request, post: UpdataAccess, db: Session = Depends(get_db)):
    access = db.query(Access).filter(Access.id == post.id).first()
    if access:
        if post.access_name is not None:
            access.access_name = post.access_name
        if post.access_desc is not None:
            access.access_desc = post.access_desc
        if post.scopes is not None:
            access.scopes = post.scopes
        try:
            db.commit()
            db.close()
        except Exception as e:
            print(e)
            return fail(msg="修改失败")
        return success(msg="修改成功")
    return fail(msg="未查询到该通行证")


@router.post("/accessrole",
            tags=["通行证管理"],
            summary="修改通行证关联角色",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def updataAccessRole(req: Request, post: RoleAccess, db: Session = Depends(get_db)):
    access = db.query(Access).filter(Access.id == post.id).first()
    if access:
        access.roles = []
        for i in post.roles:
            role = db.query(Role).filter(Role.id == i).first()
            if role:
                access.roles.append(role)
        try:
            db.commit()
            db.close()
        except Exception as e:
            print(e)
            return fail(msg="修改失败")
        return success(msg="修改成功")
    return fail(msg="未查询到该通行证")


@router.post("/accessmenu",
             tags=["通行证管理"],
             summary="增加通行证关联菜单",
             dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def updataAccessMenu(req: Request, post: CreateMenu, db: Session = Depends(get_db)):
    access = db.query(Access).filter(Access.id == post.access_id).first()
    if access:
        if post.id:
            menu = db.query(Menu).filter(Menu.id == post.id).first()
            if menu:
                menu.path = post.path
                menu.name = post.name
                menu.url = post.url
                menu.icon = post.icon
                menu.child_menus = []
                if len(post.child_menus) > 0:
                    for i in post.child_menus:
                        child_menu = ChildMenu(path=i.get("path"), name=i.get("name"), url=i.get("url"))
                        menu.child_menus.append(child_menu)
                try:
                    db.commit()
                    db.close()
                    return success(msg="修改成功")
                except Exception as e:
                    print(e)
                    return fail(msg="修改失败")
            else:
                return fail(msg="为查询到菜单")
        else:
            newMenu = Menu(path=post.path, name=post.name, url=post.url, icon=post.icon, access_id=post.access_id)
            if len(post.child_menus) > 0:
                for i in post.child_menus:
                    child_menu = ChildMenu(path=i.path, name=i.name, url=i.url)
                    newMenu.child_menus.append(child_menu)
            try:
                db.add(newMenu)
                db.commit()
                db.close()
                return success(msg="添加成功")
            except Exception as e:
                print(e)
                return fail(msg="添加失败")
    else:
        return fail(msg="未查询到对应通行证")


@router.delete("/deletemenu/{id}",
            tags=["通行证管理"],
            summary="删除通行证菜单",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def deleteMenu(req: Request, id: int, db: Session = Depends(get_db)):
    query = db.query(Menu).filter(Menu.id == id)
    if query.first():
        query.delete()
        db.commit()
        db.close()
        return success(msg="删除成功")
    return fail(msg="删除失败")


@router.delete("/deleteaccess/{id}",
            tags=["通行证管理"],
            summary="删除通行证",
            dependencies=[Security(check_permissions, scopes=["role_add", "access_add"])])
async def deleteAccess(req: Request, id: int, db: Session = Depends(get_db)):
    query = db.query(Access).filter(Access.id == id)
    if query.first():
        query.delete()
        db.commit()
        db.close()
        return success(msg="删除成功")
    return fail(msg="删除失败")


@router.get("/vistorlist",
            tags=["普通用户管理"],
            summary="获取普通用户列表",
            dependencies=[Security(check_permissions, scopes=["vistor_add"])])
async def getVistorList(req: Request, db: Session = Depends(get_db)):
    datas = []
    # 查询参数中若有name，则进行用户模糊查询
    name = req.query_params.get("name")
    if name:
        # 多条件查询时不能使用and，条件用逗号隔开即可
        users = db.query(User).filter(User.username.like(f'{name}%'), User.role_id == vistor_role_id).all()  # like模糊查询
        total = len(users)
        # 返回数据包括用户信息和角色信息
        for user in users:
            GetRelationShip(user)
            datas.append(user)
        data = {
            "total": total,
            "data": datas
        }
        return success(msg="获取成功", data=data)
    # 若没有name查询参数
    users = db.query(User).all()
    # 获取总数让前端好进行分页
    total = len(users)
    # 若有page和limit则进行分页查询
    page = req.query_params.get("page")
    limit = req.query_params.get("limit")
    if page and limit:
        page = int(page)
        limit = int(limit)
        users = db.query(User).filter(User.role_id == vistor_role_id).order_by(User.id.asc()).offset((page - 1) * limit).limit(limit).all()  # desc()倒序，asc()正序
    for user in users:
        GetRelationShip(user)
        datas.append(user)
    data = {
        "total": total,
        "data": datas
    }
    return success(msg="获取成功", data=data)


@router.post("/vistoradd",
             tags=["普通用户管理"],
             summary="管理员创建游客",
             dependencies=[Security(check_permissions, scopes=["vistor_add"])])
async def vistor_add(req: Request, post: CreateVistor, db: Session = Depends(get_db)):
    if not post.password:
        post.password = '123456'
    post.role_id = vistor_role_id
    newUser = User(**post.dict())
    newUser.password = en_password(newUser.password)
    if post.role_id:
        newUser.role_id = post.role_id
    try:
        db.add(newUser)
        db.commit()
        user = db.query(User).filter(User.username == post.username).first()
        user.identify_id = code_identity(user.id)
        db.commit()
        db.close()
    except Exception as e:
        if "Duplicate entry" in str(e):
            return fail(msg="用户名重复")
    return success(msg="添加成功")


@router.put("/vistorupdata",
            tags=["普通用户管理"],
            summary="修改游客资料",
            dependencies=[Security(check_permissions, scopes=["vistor_add"])])
async def putVistorData(req: Request, post: UpdateVistor, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == post.id, User.role_id == vistor_role_id).first()
    # db.commit()
    # db.close()
    # return success(msg="修改成功", data=user.first())
    # 若用id查询到对应用户，则进行数据判断和修改
    if user:
        if post.nickname is not None:
            user.nickname = post.nickname
        if post.user_phone is not None:
            user.user_phone = post.user_phone
        if post.user_status is not None:
            user.user_status = post.user_status
        if post.sex is not None:
            user.sex = post.sex
        if post.role_id is not None:
            user.role_id = post.role_id
        if post.username is not None:
            user.username = post.username
        try:
            db.commit()
            db.close()
            return success(msg="修改成功", data=user)
        except Exception as e:
            print(e)
            if "Duplicate entry" in str(e):
                return fail(msg="用户名重复")
    else:
        return fail(msg="未查询到该用户")


@router.delete("/vistordelete/{id}",
               tags=["普通用户管理"],
               summary="删除普通用户",
               dependencies=[Security(check_permissions, scopes=["vistor_add"])])
async def deleteVistorData(req: Request, id: int, db: Session = Depends(get_db)):
    query = db.query(User).filter(User.id == id, User.role_id == vistor_role_id)
    if query.first():
        query.delete()
        db.commit()
        db.close()
        return success(msg="删除成功")
    return fail(msg="删除失败")


@router.get("/vistorreset/{id}",
            tags=["普通用户管理"],
            summary="重置游客密码",
            dependencies=[Security(check_permissions, scopes=["vistor_add"])])
async def resetPassword(req: Request, id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == id, User.role_id == vistor_role_id).first()
    if user:
        user.password = en_password("123456")
        db.commit()
        db.close()
        return success(msg="重置成功")
    return fail(msg="重置失败")


@router.post("/loglist",
            tags=["登录日志"],
            summary="查询登录日志",
            dependencies=[Security(check_permissions, scopes=["log_add"])])
async def getLogList(req: Request, post: AccessLogQuery, db: Session = Depends(get_db)):
    if post.user_id is not None:
        total = db.query(AccessLog).filter(AccessLog.user_id == post.user_id).all()
        logs = db.query(AccessLog).filter(AccessLog.user_id == post.user_id).order_by(AccessLog.create_time).\
            offset((post.page - 1) * post.limit).limit(post.limit).all()
        return success(msg="获取成功", data={
            "total": len(total),
            "logs": logs
        })
    if post.username is not None:
        user = db.query(User).filter(User.username == post.username).first()
        if user:
            total = db.query(AccessLog).filter(AccessLog.user_id == user.id).all()
            logs = db.query(AccessLog).filter(AccessLog.user_id == user.id).order_by(AccessLog.create_time). \
                offset((post.page - 1) * post.limit).limit(post.limit).all()
            return success(msg="获取成功", data={
                "total": len(total),
                "logs": logs
            })
        return fail(msg="未查询到该用户")
    return success(msg="获取成功")


@router.get("/testadd",
            tags=["测试添加"],
            summary="管理员创建用户")
async def test_account_add(req: Request, db: Session = Depends(get_db)):
    user = User()
    user.username = "rat"
    user.password = en_password("123456")
    db.add(user)
    db.commit()
    return success(msg='添加成功')

