# -*- coding:utf-8 -*-
"""
@Time : 2023/4/4
@Author: Sylphiette
@Des: websocket连接
"""
import time
import json
from fastapi import APIRouter, Security, Depends
from starlette.endpoints import WebSocketEndpoint
from starlette.websockets import WebSocket, WebSocketDisconnect
from jwt import PyJWTError
from pydantic import ValidationError
import jwt
from config import settings
from models.base import User
from schemas.base import WebsocketMessage
from typing import Any
from fastapi.responses import HTMLResponse
from database.mysql import WithBaseDb
from core.Response import fail, success
from core.Auth import check_permissions
from database.mysql import get_db
from sqlalchemy.orm import Session

router = APIRouter(prefix="/ws")


def check_token(token: str):
    """
    用户验证
    :param token:
    :return:
    """
    try:
        # token解密
        payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
        if payload:
            # 用户ID
            uid = payload.get("user_id", 0)
            if uid == 0:
                return False
        else:
            return False
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False
    except (PyJWTError, ValidationError):
        return False
    return uid


class ConnectionManager:
    def __init__(self):
        self.active_connections = []

    async def connect(self, websocket: WebSocket, uid: int):
        await websocket.accept()
        self.active_connections.append({
            "ws": websocket,
            "uid": int(uid)
        })

    def disconnect(self, websocket: WebSocket):
        for con in self.active_connections:
            if con["ws"] == websocket:
                self.active_connections.remove(con)

    async def send_personal_message(self, message: Any, websocket: WebSocket):
        await websocket.send_json(message)

    async def broadcast(self, message: Any):
        for connection in self.active_connections:
            await connection["ws"].send_json(message)


manager = ConnectionManager()


@router.websocket("/socket/{token}")
async def websocket_endpoint(websocket: WebSocket, token: str):
    login_force_message = {
        "isSystem": True,
        "data": "login in other ip"
    } # 系统消息，在其他ip登录
    refresh_user_message = {
        "isSystem": True,
        "data": "refresh"
    } # 系统消息， 登录成员有变化
    # 检查token是否有效
    try:
        uid = check_token(token)
        if not uid:
            raise WebSocketDisconnect
        # 该用户是否已经连接，若连接则剔除原连接
        for con in manager.active_connections:
            if con["uid"] == uid:
                manager.disconnect(con["ws"])
                await manager.send_personal_message(login_force_message, con["ws"])
        await manager.connect(websocket, uid)
        await manager.broadcast(refresh_user_message) # 发送登录成员变化消息
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            # 选择与人聊天
            if data["isSystem"] is False and data["toUserId"]:
                for con in manager.active_connections:
                    if con["uid"] == data["toUserId"]:
                        await manager.send_personal_message(data, con["ws"])
                        await manager.send_personal_message(data, websocket)

    except WebSocketDisconnect:
        manager.disconnect(websocket)
        await manager.broadcast(refresh_user_message) # 发送登录成员变化消息


@router.get("/online",
            tags=["对话管理"],
            summary="获取在线用户",
            dependencies=[Security(check_permissions)])
async def get_online_user(db: Session = Depends(get_db)):
    """
    获取在线用户
    :param db:
    :return:
    """
    online_user = []
    for con in manager.active_connections:
        user = db.query(User).filter(User.id == con["uid"]).first()
        if user:
            if user.role:
                pass
            online_user.append(user)
    return success(msg="获取成功", data=online_user)
