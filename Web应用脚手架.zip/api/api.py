# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : api.py
# @Des: 接口路由管理
from fastapi import APIRouter
from api.account.admin import router as admin_router
from api.account.websocket import router as ws_router
from api.account.login import router as login_router

api_router = APIRouter(prefix="/api")
api_router.include_router(admin_router)
api_router.include_router(ws_router)
api_router.include_router(login_router)