# -*- coding:utf-8 -*-
# @Created on : 2023/2/16 16:54
# @Author: Sylphiette
# @File : App.py
# @Des: 启动app
from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
import uvicorn
from core import Events, Exceptions, Middleware
from config import settings
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.staticfiles import StaticFiles
from fastapi.openapi.docs import (get_redoc_html, get_swagger_ui_html, get_swagger_ui_oauth2_redirect_html)
from fastapi.openapi.utils import get_openapi
from core.Router import router
from fastapi.templating import Jinja2Templates

app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.DESCRIPTION,
    version=settings.VERSION,
    docs_url='/docs',
    redoc_url='/redocs',
    debug=settings.APP_DEBUG
)

# 事件监听
app.add_event_handler("startup", Events.startup(app)) # add_event_handler添加事件
app.add_event_handler("shutdown", Events.stopping(app))

# 异常错误处理
app.add_exception_handler(HTTPException, Exceptions.http_error_handler)
app.add_exception_handler(RequestValidationError, Exceptions.http422_error_handler)
app.add_exception_handler(Exceptions.UnicornException, Exceptions.unicorn_exception_handler)

# 跨域资源
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
    allow_methods=settings.CORS_ALLOW_METHODS,
    allow_headers=settings.CORS_ALLOW_HEADERS,
)
# 中间件
app.add_middleware(Middleware.BaseMiddleware)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.SECRET_KEY,
    session_cookie=settings.SESSION_COOKIE,
    max_age=settings.SESSION_MAX_AGE
)

# 挂载静态目录
app.mount('/static', StaticFiles(directory=settings.STATIC_DIR))
app.state.views = Jinja2Templates(directory=settings.TEMPLATE_DIR)


# custom_openapi
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        description=settings.DESCRIPTION,
        version=settings.VERSION,
        title=settings.PROJECT_NAME,
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "/logo-teal.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# redoc
@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=app.title + " - ReDoc",
        redoc_js_url="/redoc.standalone.js",
    )


app.include_router(router)

if __name__ == "__main__":
    uvicorn.run(app="app:app", port=settings.PORT, host=settings.HOST, reload=True)